from module_one import f

if __name__ == "__main__":
    a=f(10,5)
    print(a)
