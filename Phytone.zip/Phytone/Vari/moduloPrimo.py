def function_name(x):
    print("loooool:",x)