import b

def f(x):
    return x * 2


def f2(x):
    return x * 22

if __name__ == "__main__":
    print(1)
    print(b.f(10))
    print(f(10))