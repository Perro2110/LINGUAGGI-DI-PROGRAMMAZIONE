import a

def f(x):
    return x / 2

if __name__ == "__main__":
    print(1)
    print(a.f(10))
    print(f(10))