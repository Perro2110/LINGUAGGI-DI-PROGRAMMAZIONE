from typing import Any


class SuperMercati:
    def __init__(self,codice,tipo,indirizzo,superficie,numeroDiAddetti) -> None:
        self.codice = codice
        self.tipo   = tipo
        self.indirizzo = indirizzo
        self.superficie = superficie
        self.numeroDiAddetti = numeroDiAddetti
    