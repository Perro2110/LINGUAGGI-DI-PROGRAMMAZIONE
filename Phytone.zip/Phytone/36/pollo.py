x = input("inserire valore: ")
print(x)