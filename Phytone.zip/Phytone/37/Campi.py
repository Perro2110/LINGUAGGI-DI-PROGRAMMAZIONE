class Campi:
    def __init__(self,codice,tipo,nomeCampo,larghezza,lunghezza,costoOrario) -> None:
        self.codice = codice
        self.tipo   = tipo
        self.nomeCampo = nomeCampo
        self.larghezza = larghezza
        self.lunghezza = lunghezza
        self.costoOrario = costoOrario
    