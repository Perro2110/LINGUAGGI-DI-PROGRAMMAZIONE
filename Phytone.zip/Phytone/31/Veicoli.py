class Veicoli:
    def __init__(self,codice,tipo,targa,modello,marca,costoGiornaliero) -> None:
        self.codice  = codice
        self.tipo    = tipo 
        self.targa   = targa 
        self.modello = modello 
        self.marca   = marca 
        self.costoGiornaliero = costoGiornaliero
        