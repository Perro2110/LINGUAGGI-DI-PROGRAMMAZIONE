class Corsi:
    def __init__(self,codice,tipo,nomeDelCorso,nomeCognome) -> None:
        self.codice       = codice
        self.tipo         = tipo
        self.nomeDelCorso = nomeDelCorso
        self.nomeCognome  = nomeCognome
