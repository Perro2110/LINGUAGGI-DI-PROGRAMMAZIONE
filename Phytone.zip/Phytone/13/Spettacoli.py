class Spettacoli:
    def __init__(self,titolo,cod,tipo,produttore,anno) -> None:
        self.titolo = titolo
        self.cod    = cod
        self.tipo   = tipo 
        self.produttore = produttore
        self.anno   = anno