class Squadra:
    def __init__(self,cod,tipo,nomeSquadra,numPartiteVinte,numPartitePerse) -> None:
        self.cod = cod
        self.tipo = tipo 
        self.nomeSquadra = nomeSquadra
        self.numPartiteVinte = numPartiteVinte
        self.numPartitePerse = numPartitePerse
        