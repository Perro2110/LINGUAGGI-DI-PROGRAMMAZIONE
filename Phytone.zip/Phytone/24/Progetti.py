class Progetti:
    def __init__(self,cod,tipo,titolo,nomeCognomeCoordinatore,organizzazione,importoTotaleInMilioniDiEuro) -> None:
        self.cod = cod
        self.tipo = tipo
        self.titolo = titolo
        self.nomeCognomeCoordinatore = nomeCognomeCoordinatore
        self.organizzazione = organizzazione 
        self.importoTotaleInMilioniDiEuro = importoTotaleInMilioniDiEuro

