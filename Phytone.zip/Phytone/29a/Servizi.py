class Servizi:
    def __init__(self,cod,numOre) -> None:
        self.cod    = cod
        self.numOre = numOre
        