class  Articoli:
    def __init__(self,cod,tipo,marca,taglia,modello,costo,scontoInPercentuale) -> None:
        self.cod = cod
        self.tipo = tipo
        self.marca = marca
        self.taglia = taglia
        self.modello = modello
        self.costo = costo
        self.scontoInPercentuale = scontoInPercentuale