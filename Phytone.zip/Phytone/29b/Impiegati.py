class Impiegati:
    def __init__(self,cod,tipo,nomeDipendete,costoorario) -> None:
            self.cod  = cod
            self.tipo = tipo
            self.nomeDipendete = nomeDipendete
            self.costoorario = costoorario