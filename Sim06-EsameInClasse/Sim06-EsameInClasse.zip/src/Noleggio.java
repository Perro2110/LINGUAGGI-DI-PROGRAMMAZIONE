public class Noleggio {
    int v;
    int giorno;
    public int getV() {
        return v;
    }
    public int getGiorno() {
        return giorno;
    }
    public Noleggio(int v, int giorno) {
        this.v = v;
        this.giorno = giorno;
    }
}
